## Generell info
PS! For å åpne denne filen i Markdown Preview, høyre-klikk på filen, velg "Open with" og deretter "Markdown Preview". Da vil du lettere kunne lese filen og klikke på lenkene.

Dette kan settes som "default" på følgende måte:
- Klikk på "Settings" i menyen
- Velg "Settings Editor"
- Kikk på "Document Manager"
- Klikk på "Add"
- Erstatt "newKey" med "markdown" og "New Value" med "Markdown Preview".

Dersom du ønsker å få nye versjoner av filene (kast bort dine endringer), kan du slette de filene du ikke vil ha og klikke på lenken i Blackboard.

## Komme i gang

Klikk på **Øving 2** under arbeidskrav i Blackboard slik at du får med alle filene i øvingen på Jupyter Hub. Sjekk at filene er nylig kopiert (tidsstempel). Deretter starter du med **0_Forside.ipynb** og jobber deg gjennom alle oppgavene. Vi anbefaler at du jobber med leksjonene (Gå til fremsdriftsplan og aktuell uke i Blackboard) i forkant.

## Innlevering
Øvingen leveres for godkjenning i Blackboard (Se under arbeidskrav). NB! Sørg for at du har lagret alle filene for innlevering! Fra **File** menyen, velg "Save All" før du går videre.
Zip alle filene og last opp. Fra [Jupyter server](https://jupyterhub.apps.stack.it.ntnu.no/), kan du gjennomføre denne kommandoen i et terminal vindu: **zip -r oving_2.zip oving_2.git/**. En zipfil kalt **oving_2.zip** blir laget i rot-folderen. Denne kan du laste ned på din maskin og deretter lever i Blackboard.

Følg disse trinnene:

1. Forsikre om at du er i rot-katalogen og deretter åpne et **terminal** vindu:

<img src="Figurer/jupyter_1.png">

2. Zip alle filene:

<img src="Figurer/jupyter_2.png">

3. Last ned til din lokale datamaskin:

<img src="Figurer/jupyter_3.png">

4. Lever zip-filen i BB.
