## Generell info
PS! For å åpne denne filen i Markdown Preview, høyre-klikk på filen, velg "Open with" og deretter "Markdown Preview". Da vil du lettere kunne lese filen og klikke på lenkene.

Dette kan settes som "default" på følgende måte:
- Klikk på "Settings" i menyen
- Velg "Settings Editor"
- Kikk på "Document Manager"
- Klikk på "Add"
- Erstatt "newKey" med "markdown" og "New Value" med "Markdown Preview".

Dersom du ønsker å få nye versjoner av filene (kast bort dine endringer), kan du slette de filene du ikke vil ha og klikke på lenken i Blackboard.


## Innlevering
Øvingen leveres for godkjenning i Blackboard (Se under arbeidskrav).
Slik zipper du alle filene og laster opp i Blackboard:

1. Sørg for at du er i rot folderen (altså nivået over øving_1.git). Åpne deretter et terminal vindu og gjennomfør denne kommandoen: **zip oving_1.zip oving_1.git/**

<img src="Figurer/jupyter_1.png">

2. Zip alle filene:

<img src="Figurer/jupyter_2.png">

3. Last ned til din lokale datamaskin:

<img src="Figurer/jupyter_3.png">

4. Lever zip-filen i BB.
