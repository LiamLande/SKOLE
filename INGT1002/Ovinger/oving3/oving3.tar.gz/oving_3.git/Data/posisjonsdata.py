
import numpy as np
from random import random, seed
seed(17)

a = 1
v = 0
s = 0
std = 0.3
h = 1e-3

akselerasjonsData = np.ones(10000)
for i in range(10000):
    akselerasjonsData[i] += (2.0 * random() - 1) * 1e-3

posisjonsData = [0, 0]

for a in akselerasjonsData:
    v += (a + (2.0 * random() - 1) * std) * h
    s += v * h
    posisjonsData.append(s)